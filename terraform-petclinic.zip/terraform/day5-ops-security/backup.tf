# 태스크 5 — DB 백업 CronJob (매일 03:00 KST mysqldump → PVC 5Gi, 7일 보관)
resource "kubectl_manifest" "backup" {
  for_each  = local.split.backup
  yaml_body = each.value
}

# 백업 파일 검증 Pod (gzip 무결성 · CREATE TABLE · INSERT · owners 행 수 · Dump completed)
#   수동 Job 으로 즉시 백업:  kubectl -n petclinic create job pc-db-backup-manual --from=cronjob/pc-db-backup
resource "kubectl_manifest" "backup_check" {
  count      = var.run_backup_check ? 1 : 0
  yaml_body  = file("${path.module}/manifests/91-backup-check.yaml")
  depends_on = [kubectl_manifest.backup]
}
