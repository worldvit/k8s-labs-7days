variable "aws_profile" {
  type    = string
  default = "p6762"
}

variable "region" {
  type    = string
  default = "ap-northeast-2"
}

variable "account_id" {
  description = "실습 계정. 프로바이더 allowed_account_ids 가드에 쓴다."
  type        = string
  default     = "676206941602"
}

variable "project_tag" {
  type    = string
  default = "petclinic"
}

variable "cluster_name" {
  type    = string
  default = "pc-eks"
}

variable "cluster_version" {
  type    = string
  default = "1.36"
}

variable "vpc_cidr" {
  type    = string
  default = "10.0.0.0/16"
}

# 교안 이름표: AZ 2a·2c × 퍼블릭(/24)·앱(/20)·DB(/24)
variable "subnets" {
  type = map(object({ az = string, public = string, app = string, db = string }))
  default = {
    a = { az = "ap-northeast-2a", public = "10.0.0.0/24", app = "10.0.16.0/20", db = "10.0.100.0/24" }
    c = { az = "ap-northeast-2c", public = "10.0.1.0/24", app = "10.0.32.0/20", db = "10.0.101.0/24" }
  }
}

variable "domain" {
  description = "실습 하위 도메인(별도 호스팅 영역으로 위임)"
  type        = string
  default     = "cont.itskillboost.com"
}

variable "parent_zone_id" {
  description = "상위 존 itskillboost.com. 이 존에는 cont NS 레코드 1건만 만든다."
  type        = string
  default     = "Z047656838WSW98LESM2K"
}

variable "create_parent_ns_record" {
  description = "상위 존에 NS 위임 레코드를 만들지. 운영 존 변경이므로 승인 후 true."
  type        = bool
  default     = true
}

variable "public_access_cidrs" {
  description = "EKS API 퍼블릭 엔드포인트 허용 CIDR. 실습 5 태스크 4에서 강사 IP/32 로 좁힌다."
  type        = list(string)
  default     = ["0.0.0.0/0"]
}

variable "admin_principal_arns" {
  description = "클러스터 관리자 액세스 항목을 줄 IAM 주체(예: 강사 콘솔 사용자 kevin). 생성자(pc-lab)는 자동."
  type        = list(string)
  default     = ["arn:aws:iam::676206941602:user/kevin"]
}

variable "addon_versions" {
  description = "실습 시점에 확인한 EKS 애드온 버전"
  type        = map(string)
  default = {
    "vpc-cni"                = "v1.22.4-eksbuild.3"
    "coredns"                = "v1.14.7-eksbuild.11"
    "kube-proxy"             = "v1.36.0-eksbuild.48"
    "eks-pod-identity-agent" = "v1.4.1-eksbuild.2"
    "aws-ebs-csi-driver"     = "v1.67.1-eksbuild.1"
    "metrics-server"         = "v0.9.0-eksbuild.14"
  }
}

variable "lbc_chart_version" {
  type    = string
  default = "3.6.0"
}
