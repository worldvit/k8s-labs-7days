# 태스크 5 — 관리형 노드그룹 2개 (시스템·관측 전용, taint 로 앱과 분리)
locals {
  nodegroups = {
    ng-critical = {
      subnets = [for s in aws_subnet.app : s.id] # 2a·2c
      size    = 2
      label   = "critical"
      taint   = { key = "CriticalAddonsOnly", value = "true", effect = "NO_SCHEDULE" }
    }
    ng-platform = {
      subnets = [aws_subnet.app["a"].id] # 2a 고정: Prometheus EBS가 한 AZ에 묶인다
      size    = 1
      label   = "platform"
      taint   = { key = "pc/role", value = "platform", effect = "NO_SCHEDULE" }
    }
  }
}

resource "aws_eks_node_group" "this" {
  for_each        = local.nodegroups
  cluster_name    = aws_eks_cluster.this.name
  node_group_name = each.key
  node_role_arn   = aws_iam_role.node.arn
  subnet_ids      = each.value.subnets
  instance_types  = ["t3.large"]
  capacity_type   = "ON_DEMAND"
  ami_type        = "AL2023_x86_64_STANDARD"
  disk_size       = 30

  scaling_config {
    min_size     = 0 # pc-stop.sh 가 0대로 줄일 수 있게
    max_size     = each.value.size
    desired_size = each.value.size
  }

  update_config {
    max_unavailable = 1
  }

  labels = { "pc/role" = each.value.label }

  taint {
    key    = each.value.taint.key
    value  = each.value.taint.value
    effect = each.value.taint.effect
  }

  # pc-stop.sh / pc-start.sh 가 바꾸는 대수는 Terraform 이 되돌리지 않는다
  lifecycle {
    ignore_changes = [scaling_config[0].desired_size]
  }

  depends_on = [
    aws_iam_role_policy_attachment.node,
    aws_eks_addon.before_nodes,
  ]
}
