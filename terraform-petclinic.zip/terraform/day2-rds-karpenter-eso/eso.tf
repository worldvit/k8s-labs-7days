# 태스크 3 — External Secrets Operator (rds!db-* 비밀만 읽는 최소 권한)
resource "aws_iam_policy" "eso" {
  name   = "pc-policy-eso"
  policy = templatefile("${path.module}/policies/pc-policy-eso.json.tftpl", { account_id = local.account_id })
}

resource "aws_iam_role" "eso" {
  name               = "pc-pi-eso"
  assume_role_policy = data.aws_iam_policy_document.pod_identity_assume.json
}

resource "aws_iam_role_policy_attachment" "eso" {
  role       = aws_iam_role.eso.name
  policy_arn = aws_iam_policy.eso.arn
}

resource "aws_eks_pod_identity_association" "eso" {
  cluster_name    = var.cluster_name
  namespace       = "external-secrets"
  service_account = "external-secrets"
  role_arn        = aws_iam_role.eso.arn
}

resource "helm_release" "eso" {
  name             = "external-secrets"
  repository       = "https://charts.external-secrets.io"
  chart            = "external-secrets"
  version          = var.eso_chart_version
  namespace        = "external-secrets"
  create_namespace = true

  values = [yamlencode({
    installCRDs    = true
    serviceAccount = { create = true, name = "external-secrets" }
    nodeSelector   = local.critical_selector
    tolerations    = local.critical_toleration
    webhook        = { nodeSelector = local.critical_selector, tolerations = local.critical_toleration }
    certController = { nodeSelector = local.critical_selector, tolerations = local.critical_toleration }
  })]

  depends_on = [aws_eks_pod_identity_association.eso, aws_iam_role_policy_attachment.eso]
}

resource "kubectl_manifest" "cluster_secret_store" {
  yaml_body = yamlencode({
    apiVersion = "external-secrets.io/v1"
    kind       = "ClusterSecretStore"
    metadata   = { name = "pc-aws-sm" }
    spec = {
      provider = { aws = { service = "SecretsManager", region = var.region } }
    }
  })
  depends_on = [helm_release.eso]
}
