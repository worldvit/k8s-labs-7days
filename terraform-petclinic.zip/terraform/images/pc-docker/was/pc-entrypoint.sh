#!/bin/sh
set -e
: "${DB_HOST:?DB_HOST required}" "${DB_USER:?DB_USER required}" "${DB_PASS:?DB_PASS required}"
esc() { printf '%s' "$1" | sed 's/\\/\\\\/g'; }
cat >> /usr/local/tomcat/conf/catalina.properties <<PROPS
jdbc.url=jdbc:mysql://${DB_HOST}:3306/petclinic?useUnicode=true
jdbc.username=$(esc "$DB_USER")
jdbc.password=$(esc "$DB_PASS")
PROPS
unset DB_PASS
exec catalina.sh run
