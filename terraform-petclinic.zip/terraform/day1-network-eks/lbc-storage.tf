# 태스크 7 — 기본 StorageClass pc-gp3 (gp3 · 암호화 · WaitForFirstConsumer)
resource "kubernetes_storage_class_v1" "pc_gp3" {
  metadata {
    name        = "pc-gp3"
    annotations = { "storageclass.kubernetes.io/is-default-class" = "true" }
  }
  storage_provisioner    = "ebs.csi.aws.com"
  volume_binding_mode    = "WaitForFirstConsumer"
  reclaim_policy         = "Delete"
  allow_volume_expansion = true
  parameters = {
    type      = "gp3"
    encrypted = "true"
  }
  depends_on = [aws_eks_addon.ebs_csi]
}

# 태스크 8 — AWS Load Balancer Controller (Pod Identity · critical 노드)
resource "aws_iam_policy" "lbc" {
  name   = "pc-policy-lbc"
  policy = file("${path.module}/policies/pc-policy-lbc.json") # 공식 v3.6.0 iam_policy.json
}

resource "aws_iam_role" "lbc" {
  name               = "pc-pi-lbc"
  assume_role_policy = data.aws_iam_policy_document.pod_identity_assume.json
}

resource "aws_iam_role_policy_attachment" "lbc" {
  role       = aws_iam_role.lbc.name
  policy_arn = aws_iam_policy.lbc.arn
}

resource "aws_eks_pod_identity_association" "lbc" {
  cluster_name    = aws_eks_cluster.this.name
  namespace       = "kube-system"
  service_account = "aws-load-balancer-controller"
  role_arn        = aws_iam_role.lbc.arn
}

resource "helm_release" "lbc" {
  name       = "aws-load-balancer-controller"
  repository = "https://aws.github.io/eks-charts"
  chart      = "aws-load-balancer-controller"
  version    = var.lbc_chart_version
  namespace  = "kube-system"

  values = [yamlencode({
    clusterName    = aws_eks_cluster.this.name
    region         = var.region
    vpcId          = aws_vpc.this.id
    serviceAccount = { create = true, name = "aws-load-balancer-controller" }
    nodeSelector   = { "pc/role" = "critical" }
    tolerations    = [{ key = "CriticalAddonsOnly", operator = "Exists", effect = "NoSchedule" }]
  })]

  depends_on = [
    aws_eks_pod_identity_association.lbc,
    aws_iam_role_policy_attachment.lbc,
    aws_eks_addon.coredns,
  ]
}
