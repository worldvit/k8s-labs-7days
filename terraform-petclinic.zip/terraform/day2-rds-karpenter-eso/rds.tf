# 태스크 1 — RDS MySQL Multi-AZ (비밀번호는 Secrets Manager 관리형, 사람이 정하지 않음)
resource "aws_security_group" "rds" {
  name        = "pc-sg-rds"
  description = "petclinic rds - from eks cluster sg only"
  vpc_id      = data.aws_vpc.this.id
  tags        = { Name = "pc-sg-rds" }
}

# 3306 ← 클러스터 SG만 (IP 규칙 없음)
resource "aws_vpc_security_group_ingress_rule" "rds_from_cluster" {
  security_group_id            = aws_security_group.rds.id
  referenced_security_group_id = local.cluster_sg_id
  ip_protocol                  = "tcp"
  from_port                    = 3306
  to_port                      = 3306
  description                  = "mysql from eks cluster sg"
}

resource "aws_db_subnet_group" "this" {
  name       = "pc-dbsubnet"
  subnet_ids = [for s in data.aws_subnet.db : s.id]
  tags       = { Name = "pc-dbsubnet" }
}

resource "aws_db_instance" "this" {
  identifier     = "pc-rds"
  engine         = "mysql"
  engine_version = var.db_engine_version
  instance_class = var.db_instance_class

  db_name                     = "petclinic"
  username                    = "pcadmin" # 개선 과제: 앱 전용 계정 분리
  manage_master_user_password = true      # rds!db-… 비밀, 7일 자동 교체

  storage_type      = "gp3"
  allocated_storage = 20
  storage_encrypted = true

  multi_az               = true
  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [aws_security_group.rds.id]
  publicly_accessible    = false

  backup_retention_period         = 7
  copy_tags_to_snapshot           = true
  deletion_protection             = true
  enabled_cloudwatch_logs_exports = ["error", "slowquery"]
  auto_minor_version_upgrade      = true

  skip_final_snapshot       = var.db_skip_final_snapshot
  final_snapshot_identifier = var.db_skip_final_snapshot ? null : "pc-rds-final"

  tags = { Name = "pc-rds" }
}
