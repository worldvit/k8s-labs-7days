# day1 리소스 조회
data "aws_caller_identity" "this" {}

data "aws_eks_cluster" "this" {
  name = var.cluster_name
}

data "aws_vpc" "this" {
  tags = { Name = "pc-vpc" }
}

data "aws_subnet" "db" {
  for_each = toset(["a", "c"])
  vpc_id   = data.aws_vpc.this.id
  tags     = { Name = "pc-subnet-db-${each.key}" }
}

data "aws_iam_policy_document" "pod_identity_assume" {
  statement {
    actions = ["sts:AssumeRole", "sts:TagSession"]
    principals {
      type        = "Service"
      identifiers = ["pods.eks.amazonaws.com"]
    }
  }
}

locals {
  account_id          = data.aws_caller_identity.this.account_id
  cluster_sg_id       = data.aws_eks_cluster.this.vpc_config[0].cluster_security_group_id
  critical_selector   = { "pc/role" = "critical" }
  critical_toleration = [{ key = "CriticalAddonsOnly", operator = "Exists", effect = "NoSchedule" }]
}
