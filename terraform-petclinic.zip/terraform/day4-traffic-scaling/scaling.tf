# 태스크 3 — 자동 확장 규칙
#   web : HPA CPU 60% (2~6)
#   was : KEDA ScaledObject — Prometheus 초당 요청 20/Pod + 평일 09~18시 cron 3 (2~8)
#   PDB : web-pdb · was-pdb minAvailable 1
#   PodMonitor : was(9404) · web(9113) — KEDA 쿼리와 Grafana 의 지표 출처
resource "kubectl_manifest" "scaling" {
  for_each  = merge(local.docs.scaling, local.docs.podmon, local.docs.keda)
  yaml_body = each.value
}

# 태스크 4 — k6 부하 시험은 Terraform 밖(~/pc/k6, grafana/k6 컨테이너)에서 수행한다.
