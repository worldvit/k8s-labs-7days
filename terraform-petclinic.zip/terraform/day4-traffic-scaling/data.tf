data "aws_caller_identity" "this" {}

data "aws_eks_cluster" "this" {
  name = var.cluster_name
}

data "aws_route53_zone" "cont" {
  name = var.domain
}

# day1 의 ACM 인증서(ISSUED)
data "aws_acm_certificate" "this" {
  domain   = var.domain
  statuses = ["ISSUED"]
}

locals {
  registry = "${data.aws_caller_identity.this.account_id}.dkr.ecr.${var.region}.amazonaws.com"

  docs = { for name, body in {
    gateway = templatefile("${path.module}/manifests/40-gateway.yaml.tftpl", { domain = var.domain, enable_canary = var.enable_canary, canary_weight = var.enable_canary ? var.canary_weight : 0 })
    scaling = file("${path.module}/manifests/60-scaling.yaml")
    podmon  = file("${path.module}/manifests/61-podmonitor.yaml")
    keda    = file("${path.module}/manifests/62-keda.yaml")
  } : name => { for d in split("\n---\n", body) : "${yamldecode(d).kind}/${yamldecode(d).metadata.name}" => d if trimspace(d) != "" } }
}
