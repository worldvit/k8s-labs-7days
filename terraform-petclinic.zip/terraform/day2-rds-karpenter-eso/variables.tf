variable "aws_profile" {
  type    = string
  default = "p6762"
}

variable "region" {
  type    = string
  default = "ap-northeast-2"
}

variable "account_id" {
  type    = string
  default = "676206941602"
}

variable "project_tag" {
  type    = string
  default = "petclinic"
}

variable "cluster_name" {
  type    = string
  default = "pc-eks"
}

# --- RDS
variable "db_engine_version" {
  type    = string
  default = "8.4.11"
}

variable "db_instance_class" {
  type    = string
  default = "db.t3.small"
}

variable "db_skip_final_snapshot" {
  description = "철거 시 최종 스냅샷 생략 여부(실습 기본 true)"
  type        = bool
  default     = true
}

# --- Helm 차트 버전
variable "karpenter_version" {
  type    = string
  default = "1.15.0"
}

variable "eso_chart_version" {
  type    = string
  default = "2.13.0"
}
