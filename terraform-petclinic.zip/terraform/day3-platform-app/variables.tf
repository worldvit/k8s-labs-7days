variable "aws_profile" {
  type    = string
  default = "p6762"
}

variable "region" {
  type    = string
  default = "ap-northeast-2"
}

variable "account_id" {
  type    = string
  default = "676206941602"
}

variable "project_tag" {
  type    = string
  default = "petclinic"
}

variable "cluster_name" {
  type    = string
  default = "pc-eks"
}

# 이미지 태그 — ECR 은 IMMUTABLE 이므로 새 빌드는 새 태그로 push 하고 여기만 바꾼다
variable "was_tag" {
  type    = string
  default = "1.0.1"
}

variable "web_tag" {
  type    = string
  default = "1.0.0"
}

variable "keda_chart_version" {
  type    = string
  default = "2.21.0"
}

variable "ngf_chart_version" {
  type    = string
  default = "2.8.0"
}

variable "gateway_api_version" {
  description = "NGF 2.8 이 요구하는 Gateway API CRD (standard 채널)"
  type        = string
  default     = "v1.6.3"
}

variable "kps_chart_version" {
  type    = string
  default = "92.11.0"
}

# 실습 5 태스크 2 — Slack Incoming Webhook. 비워 두면 Alertmanager 수신자를 만들지 않는다.
# 값은 tfvars 파일(권한 600)이나 TF_VAR_slack_webhook_url 로만 넘긴다. 상태 파일에는 남으므로 상태 보관에 주의.
variable "slack_webhook_url" {
  type      = string
  default   = ""
  sensitive = true
}

variable "slack_channel" {
  description = "표시용. 실제 게시 채널은 Webhook 을 만들 때 고른 채널이다."
  type        = string
  default     = "#pc-alerts"
}
