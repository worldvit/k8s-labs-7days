# PetClinic 3티어 on Amazon EKS — Terraform (실습 1~5)

교안 실습 1~5(Day 1~5)에서 콘솔·CLI·kubectl·Helm으로 만든 구성을 Terraform으로 옮긴 코드다.
이름(pc-*)·태그(Project=petclinic)·CIDR·버전·Helm values·매니페스트는 실제 배포된 값과 같다.

> 이 코드는 `terraform init -backend=false` · `fmt` · `validate` 까지만 검증했다(Terraform 1.17 · aws 6.70 · helm 3.3 · kubernetes 2.38 · alekc/kubectl 2.4).
> 실습 계정(6762)에는 같은 이름의 리소스가 이미 있으므로 **그대로 apply 하면 이름 충돌로 실패한다.** 새 환경에 쓰거나, 철거 후 쓰거나, `terraform import` 로 기존 리소스를 상태에 넣은 뒤 쓴다.

## 디렉터리 구성 — 일차별 루트 모듈(상태 파일 분리)

| 디렉터리 | 교안 | 만드는 것 |
|---|---|---|
| `day1-network-eks` | 실습 1 | VPC·서브넷 6·IGW·NAT 2·EIP 2·라우팅 5, cont 하위 존 + 상위 존 NS 1건, ACM, IAM(클러스터·노드·EBS CSI·LBC), EKS 1.36, 액세스 항목, 노드그룹 2, 애드온 6, StorageClass pc-gp3, AWS Load Balancer Controller |
| `day2-rds-karpenter-eso` | 실습 2 | RDS MySQL 8.4 Multi-AZ(관리형 비밀) + SG·서브넷 그룹, Karpenter(공식 CloudFormation 스택 + Pod Identity + Helm + NodePool/EC2NodeClass), External Secrets(+ ClusterSecretStore) |
| `day3-platform-app` | 실습 3 | ECR 2(불변·스캔·수명 주기), KEDA, Gateway API CRD v1.6.3, NGINX Gateway Fabric, kube-prometheus-stack(+ Slack 수신자 옵션), petclinic 네임스페이스·DB 접속 정보·was·web |
| `day4-traffic-scaling` | 실습 4 | Gateway·HTTPRoute 2, Ingress → ALB pc-alb, Route 53 A 별칭, HPA·PDB·KEDA ScaledObject·PodMonitor, 카나리(변수로 가중치) |
| `day5-ops-security` | 실습 5 | PrometheusRule, Fluent Bit → CloudWatch Logs(7일), CloudWatch 대시보드 pc-petclinic-flow(28 위젯), WAF pc-waf + Ingress 주석, DB 백업 CronJob·PVC |
| `scripts/build-push.sh` | 실습 2·3 | Maven 컨테이너 빌드 → pc-web·pc-was 이미지 → ECR push |
| `images/pc-docker` | 실습 2·3 | web·was Dockerfile, Nginx 설정 템플릿, Tomcat 시작 스크립트, JMX 설정 |

day2~5 는 앞 단계 리소스를 **이름·태그로 조회**(data source)하므로 상태 파일을 공유하지 않는다.
쿠버네티스·Helm 프로바이더는 `aws eks get-token --profile p6762` 로 인증한다.

## 적용 순서

```bash
source ~/pc/pc-env.sh
cd day1-network-eks        && terraform init && terraform apply   # 상위 존 NS 1건 포함 — plan 확인 후 승인
aws eks update-kubeconfig --name pc-eks --region ap-northeast-2 --profile p6762
cd ../day2-rds-karpenter-eso && terraform init && terraform apply
cd ../day3-platform-app      && terraform init && terraform apply -target=aws_ecr_repository.this
../scripts/build-push.sh 1.0.0 1.0.1                                # 이미지 push
terraform apply                                                     # 플랫폼 + 앱
cd ../day4-traffic-scaling   && terraform init && terraform apply
cd ../day5-ops-security      && terraform init && terraform apply
```

### 일차 사이에 되돌아가 바꾸는 값

| 시점 | 디렉터리 | 명령 |
|---|---|---|
| 실습 4 태스크 5 카나리 | day4 | `terraform apply -var enable_canary=true -var canary_weight=10` → `=50` → `-var enable_canary=false`(원복) |
| 실습 5 태스크 2 Slack | day3 | `TF_VAR_slack_webhook_url=$(cat ~/pc/infra/.slack_url) terraform apply` — Webhook 은 상태 파일에 남는다 |
| 실습 5 태스크 4 엔드포인트 제한 | day1 | `terraform apply -var 'public_access_cidrs=["<강사 IP>/32"]'` |
| 이미지 새 버전 | day3 | `scripts/build-push.sh <새 web 태그> <새 was 태그>` 후 `-var web_tag=… -var was_tag=…` |

## 교안 단계 ↔ 코드

| 교안 | 파일 |
|---|---|
| 실습 1 태스크 1 VPC | `day1-network-eks/network.tf` |
| 실습 1 태스크 2 하위 도메인·인증서 | `day1-network-eks/dns-acm.tf` |
| 실습 1 태스크 3·4 IAM·EKS | `day1-network-eks/iam.tf`, `eks.tf`, `addons.tf` |
| 실습 1 태스크 5·6 노드그룹·연결 | `day1-network-eks/nodegroups.tf`, `eks.tf`(액세스 항목·SG 태그) |
| 실습 1 태스크 7·8 EBS CSI·StorageClass·LBC | `day1-network-eks/addons.tf`, `lbc-storage.tf` |
| 실습 2 태스크 1·5 RDS | `day2-rds-karpenter-eso/rds.tf` |
| 실습 2 태스크 2 Karpenter | `day2-rds-karpenter-eso/karpenter.tf`, `templates/karpenter-cloudformation.yaml`, `manifests/01-karpenter.yaml.tftpl` |
| 실습 2 태스크 3 ESO | `day2-rds-karpenter-eso/eso.tf` |
| 실습 2 태스크 4·실습 3 태스크 1 이미지 | `scripts/build-push.sh`, `images/pc-docker` |
| 실습 3 태스크 2 ECR | `day3-platform-app/ecr.tf` |
| 실습 3 태스크 3 플랫폼 | `day3-platform-app/platform.tf`, `values/kps-values.yaml` |
| 실습 3 태스크 4·5 앱 배포 | `day3-platform-app/app.tf`, `manifests/10-db·20-was·30-web` |
| 실습 4 태스크 1·2 Gateway·ALB·도메인 | `day4-traffic-scaling/traffic.tf` |
| 실습 4 태스크 3 확장 규칙 | `day4-traffic-scaling/scaling.tf` |
| 실습 4 태스크 5 카나리 | `day4-traffic-scaling/canary.tf` |
| 실습 5 태스크 2·3·3.5 경보·로그·대시보드 | `day5-ops-security/observability.tf` |
| 실습 5 태스크 4 WAF | `day5-ops-security/security.tf` |
| 실습 5 태스크 5 백업 | `day5-ops-security/backup.tf` |

## 콘솔·CLI 실습과 다른 점

- **Karpenter:** 교안처럼 공식 CloudFormation 템플릿을 그대로 쓰되, `aws_cloudformation_stack` 리소스로 배포한다.
- **레플리카 수:** Deployment 의 `spec.replicas` 는 HPA·KEDA 가 정하므로 Terraform 이 비교하지 않는다(`ignore_fields`). 노드그룹 `desired_size` 도 pc-stop/pc-start 가 바꾸므로 무시한다.
- **WAF 연결:** 교안과 같이 Ingress 주석(`wafv2-acl-arn`)으로 한다. day5 가 `kubernetes_annotations` 로 주석 하나만 붙인다.
- **개선 과제 1건 반영:** ECR 수명 주기 정책(태그 없는 이미지 1일 후 만료). 나머지 개선 과제(root 실행, Pod 분산, 전용 DB 계정, CNI 역할 분리, ALB 액세스 로그 등)는 보고서 7.1 대로 별도 반영한다.
- **수동으로 남는 것:** Grafana 대시보드(UI), Slack 앱·Webhook 생성, k6 부하 시험, 철거 후 Slack Webhook·pc-lab 키 정리.

## 철거

역순으로 `terraform destroy`(day5 → day1). 단,
- RDS `deletion_protection = true` → day2 에서 `false` 로 바꿔 apply 한 뒤 destroy.
- ECR `force_delete = false` → 이미지를 먼저 지우거나 값을 바꾼다.
- PVC 로 만든 EBS 는 PVC 삭제(day5·day3 destroy) 때 지워진다. 클러스터를 먼저 지우면 고아 볼륨이 남는다.
- 상위 존 NS 레코드(day1)는 운영 존 변경이므로 plan 을 확인하고 승인 후 destroy.
- Terraform 밖에서 만든 것까지 확실히 지우려면 `~/pc/teardown/pc-teardown.sh` (DRY-RUN 기본) 로 마지막 검증을 한다.
