data "aws_caller_identity" "this" {}

data "aws_eks_cluster" "this" {
  name = var.cluster_name
}

data "aws_db_instance" "this" {
  db_instance_identifier = "pc-rds"
}

locals {
  registry            = "${data.aws_caller_identity.this.account_id}.dkr.ecr.${var.region}.amazonaws.com"
  critical_selector   = { "pc/role" = "critical" }
  critical_toleration = [{ key = "CriticalAddonsOnly", operator = "Exists", effect = "NoSchedule" }]

  # 여러 문서(---)가 든 YAML 을 kind/name 키로 나눈다
  split_yaml = { for f, body in {
    db  = templatefile("${path.module}/manifests/10-db.yaml.tftpl", { db_host = data.aws_db_instance.this.address, db_secret_arn = data.aws_db_instance.this.master_user_secret[0].secret_arn })
    was = templatefile("${path.module}/manifests/20-was.yaml.tftpl", { registry = local.registry, was_tag = var.was_tag })
    web = templatefile("${path.module}/manifests/30-web.yaml.tftpl", { registry = local.registry, web_tag = var.web_tag })
  } : f => body }

  app_docs = merge([for f, body in local.split_yaml : {
    for d in split("\n---\n", body) :
    "${yamldecode(d).kind}/${yamldecode(d).metadata.name}" => d if trimspace(d) != ""
  }]...)
}
