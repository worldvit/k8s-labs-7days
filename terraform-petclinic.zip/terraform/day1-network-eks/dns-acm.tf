# 태스크 2 — 하위 도메인 위임과 인증서
resource "aws_route53_zone" "cont" {
  name    = var.domain
  comment = "petclinic lab sub-domain"
}

# 상위 존(운영)에는 cont NS 레코드 1건만. 실행 전 change 내용을 확인·승인한다.
resource "aws_route53_record" "parent_ns" {
  count   = var.create_parent_ns_record ? 1 : 0
  zone_id = var.parent_zone_id
  name    = var.domain
  type    = "NS"
  ttl     = 300
  records = aws_route53_zone.cont.name_servers
}

resource "aws_acm_certificate" "this" {
  domain_name               = var.domain
  subject_alternative_names = ["*.${var.domain}"]
  validation_method         = "DNS"
  tags                      = { Name = "pc-acm" }

  lifecycle {
    create_before_destroy = true
  }
}

# 검증 CNAME은 하위 존에만 만든다(와일드카드와 apex가 같은 레코드를 공유)
resource "aws_route53_record" "acm_validation" {
  for_each = {
    for o in aws_acm_certificate.this.domain_validation_options : o.resource_record_name => o...
  }
  zone_id         = aws_route53_zone.cont.zone_id
  name            = each.key
  type            = each.value[0].resource_record_type
  ttl             = 300
  records         = [each.value[0].resource_record_value]
  allow_overwrite = true
}

resource "aws_acm_certificate_validation" "this" {
  certificate_arn         = aws_acm_certificate.this.arn
  validation_record_fqdns = [for r in aws_route53_record.acm_validation : r.fqdn]
  depends_on              = [aws_route53_record.parent_ns]
}
