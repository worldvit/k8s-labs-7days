variable "aws_profile" {
  type    = string
  default = "p6762"
}

variable "region" {
  type    = string
  default = "ap-northeast-2"
}

variable "account_id" {
  type    = string
  default = "676206941602"
}

variable "project_tag" {
  type    = string
  default = "petclinic"
}

variable "cluster_name" {
  type    = string
  default = "pc-eks"
}

variable "domain" {
  type    = string
  default = "cont.itskillboost.com"
}

# 태스크 5 — 카나리: enable_canary=true 로 web-canary 를 띄우고 canary_weight 를 0→10→50→0 으로 바꿔 apply
variable "enable_canary" {
  type    = bool
  default = false
}

variable "canary_weight" {
  description = "web-canary 로 보낼 비율(%). enable_canary=false 이면 0 이어야 한다."
  type        = number
  default     = 0
  validation {
    condition     = var.canary_weight >= 0 && var.canary_weight <= 100
    error_message = "canary_weight 는 0~100."
  }
}

variable "web_tag" {
  description = "카나리 이미지 태그"
  type        = string
  default     = "1.0.0"
}
