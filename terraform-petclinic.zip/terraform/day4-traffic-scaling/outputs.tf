output "alb_dns_name" { value = data.aws_lb.alb.dns_name }
output "alb_arn" { value = data.aws_lb.alb.arn }
output "url" { value = "https://${var.domain}" }
output "route_weights" {
  value = var.enable_canary ? "web ${100 - var.canary_weight} : web-canary ${var.canary_weight}" : "web 100"
}
