# 실습 1 (Day 1) — 네트워크 · 도메인 · EKS 클러스터
terraform {
  required_version = ">= 1.9"
  required_providers {
    aws        = { source = "hashicorp/aws", version = "~> 6.0" }
    kubernetes = { source = "hashicorp/kubernetes", version = "~> 2.38" }
    helm       = { source = "hashicorp/helm", version = "~> 3.0" }
  }

  # 상태 파일은 기본 로컬. 팀 공유가 필요하면 아래 S3 백엔드를 쓴다(버킷도 pc- 이름 · Project 태그).
  # backend "s3" {
  #   bucket       = "pc-tfstate-676206941602"
  #   key          = "petclinic/day1.tfstate"
  #   region       = "ap-northeast-2"
  #   profile      = "p6762"
  #   use_lockfile = true
  # }
}

provider "aws" {
  region              = var.region
  profile             = var.aws_profile
  allowed_account_ids = [var.account_id] # 다른 계정이면 plan 단계에서 멈춘다

  default_tags {
    tags = { Project = var.project_tag }
  }
}

# 쿠버네티스·Helm 프로바이더는 이 디렉터리에서 만드는 클러스터를 바라본다
provider "kubernetes" {
  host                   = aws_eks_cluster.this.endpoint
  cluster_ca_certificate = base64decode(aws_eks_cluster.this.certificate_authority[0].data)
  exec {
    api_version = "client.authentication.k8s.io/v1beta1"
    command     = "aws"
    args        = ["eks", "get-token", "--cluster-name", var.cluster_name, "--region", var.region, "--profile", var.aws_profile]
  }
}

provider "helm" {
  kubernetes = {
    host                   = aws_eks_cluster.this.endpoint
    cluster_ca_certificate = base64decode(aws_eks_cluster.this.certificate_authority[0].data)
    exec = {
      api_version = "client.authentication.k8s.io/v1beta1"
      command     = "aws"
      args        = ["eks", "get-token", "--cluster-name", var.cluster_name, "--region", var.region, "--profile", var.aws_profile]
    }
  }
}
