# 태스크 1 — Gateway 와 HTTPRoute (pc-gw · pc-route · pc-route-health)
resource "kubectl_manifest" "gateway" {
  for_each  = local.docs.gateway
  yaml_body = each.value
}

# 태스크 2 — ALB (Ingress 한 장 → LBC 가 pc-alb 생성, target-type ip, 80→443, TLS13-1-2)
resource "kubectl_manifest" "ingress" {
  yaml_body = templatefile("${path.module}/manifests/50-ingress.yaml.tftpl", {
    certificate_arn = data.aws_acm_certificate.this.arn
    domain          = var.domain
    project_tag     = var.project_tag
  })

  # 실습 5 에서 day5 가 붙이는 WAF 주석(wafv2-acl-arn)은 이 yaml_body 에 없으므로
  # 다시 apply 해도 지워지지 않는다(이 리소스는 yaml_body 에 적힌 필드만 비교·적용).

  # LBC 가 ALB 를 만들어 주소를 채울 때까지 기다린다
  wait_for {
    field {
      key        = "status.loadBalancer.ingress.[0].hostname"
      value      = "^.+$"
      value_type = "regex"
    }
  }

  depends_on = [kubectl_manifest.gateway]
}

data "aws_lb" "alb" {
  name       = "pc-alb"
  depends_on = [kubectl_manifest.ingress]
}

# 도메인 연결 — cont 하위 존 A 별칭 → ALB
resource "aws_route53_record" "app" {
  zone_id = data.aws_route53_zone.cont.zone_id
  name    = var.domain
  type    = "A"
  alias {
    name                   = data.aws_lb.alb.dns_name
    zone_id                = data.aws_lb.alb.zone_id
    evaluate_target_health = true
  }
}
