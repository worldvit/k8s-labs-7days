variable "aws_profile" {
  type    = string
  default = "p6762"
}

variable "region" {
  type    = string
  default = "ap-northeast-2"
}

variable "account_id" {
  type    = string
  default = "676206941602"
}

variable "project_tag" {
  type    = string
  default = "petclinic"
}

variable "cluster_name" {
  type    = string
  default = "pc-eks"
}

variable "fluentbit_chart_version" {
  type    = string
  default = "0.2.0"
}

variable "log_retention_days" {
  type    = number
  default = 7
}

variable "waf_rate_limit" {
  description = "IP 하나가 5분 동안 보낼 수 있는 요청 수"
  type        = number
  default     = 500
}

variable "run_backup_check" {
  description = "백업 파일 검증 Pod(91-backup-check)를 띄울지"
  type        = bool
  default     = false
}
