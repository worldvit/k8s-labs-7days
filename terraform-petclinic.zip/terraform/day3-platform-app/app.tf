# 태스크 4·5 — DB 접속 정보와 앱(was·web) 배포 (~/pc/k8s/10-db, 20-was, 30-web)
resource "kubernetes_namespace_v1" "petclinic" {
  metadata {
    name   = "petclinic"
    labels = { project = var.project_tag }
  }
}

resource "kubectl_manifest" "app" {
  for_each  = local.app_docs
  yaml_body = each.value

  # 레플리카 수는 HPA·KEDA 가 정한다(Day 4) — Terraform 이 되돌리지 않게
  ignore_fields = ["spec.replicas"]

  depends_on = [
    kubernetes_namespace_v1.petclinic,
    helm_release.kps, # PodMonitor 등 이후 리소스와 같은 순서 유지
  ]
}
