# 태스크 2 — Karpenter
# 교안과 같이 Karpenter 공식 CloudFormation 템플릿(v1.15)으로 노드 역할·컨트롤러 정책 6·SQS·EventBridge 규칙 5 를 만든다.
resource "aws_cloudformation_stack" "karpenter" {
  name          = "Karpenter-${var.cluster_name}"
  template_body = file("${path.module}/templates/karpenter-cloudformation.yaml")
  parameters    = { ClusterName = var.cluster_name }
  capabilities  = ["CAPABILITY_NAMED_IAM"]
}

locals {
  karpenter_policies = [for p in [
    "NodeLifecycle", "IAMIntegration", "EKSIntegration", "Interruption", "ZonalShift", "ResourceDiscovery",
  ] : "arn:aws:iam::${local.account_id}:policy/KarpenterController${p}Policy-${var.cluster_name}"]
}

# 컨트롤러 역할 pc-pi-karpenter (Pod Identity)
resource "aws_iam_role" "karpenter" {
  name               = "pc-pi-karpenter"
  assume_role_policy = data.aws_iam_policy_document.pod_identity_assume.json
}

resource "aws_iam_role_policy_attachment" "karpenter" {
  for_each   = toset(local.karpenter_policies)
  role       = aws_iam_role.karpenter.name
  policy_arn = each.value
  depends_on = [aws_cloudformation_stack.karpenter]
}

resource "aws_eks_pod_identity_association" "karpenter" {
  cluster_name    = var.cluster_name
  namespace       = "kube-system"
  service_account = "karpenter"
  role_arn        = aws_iam_role.karpenter.arn
}

# Karpenter 노드가 클러스터에 가입하도록 노드 역할 액세스 항목
resource "aws_eks_access_entry" "karpenter_node" {
  cluster_name  = var.cluster_name
  principal_arn = "arn:aws:iam::${local.account_id}:role/KarpenterNodeRole-${var.cluster_name}"
  type          = "EC2_LINUX"
  depends_on    = [aws_cloudformation_stack.karpenter]
}

resource "helm_release" "karpenter" {
  name       = "karpenter"
  repository = "oci://public.ecr.aws/karpenter"
  chart      = "karpenter"
  version    = var.karpenter_version
  namespace  = "kube-system"

  values = [yamlencode({
    settings     = { clusterName = var.cluster_name, interruptionQueue = var.cluster_name }
    nodeSelector = local.critical_selector
    controller = {
      resources = {
        requests = { cpu = "500m", memory = "512Mi" }
        limits   = { cpu = "1", memory = "1Gi" }
      }
    }
  })]

  depends_on = [
    aws_eks_pod_identity_association.karpenter,
    aws_iam_role_policy_attachment.karpenter,
    aws_eks_access_entry.karpenter_node,
  ]
}

# EC2NodeClass pc-app · NodePool np-app (~/pc/k8s/01-karpenter.yaml)
resource "kubectl_manifest" "karpenter" {
  for_each = {
    for d in split("\n---\n", templatefile("${path.module}/manifests/01-karpenter.yaml.tftpl", {
      cluster_name = var.cluster_name
      project_tag  = var.project_tag
    })) : yamldecode(d).kind => d
  }
  yaml_body  = each.value
  depends_on = [helm_release.karpenter]
}
