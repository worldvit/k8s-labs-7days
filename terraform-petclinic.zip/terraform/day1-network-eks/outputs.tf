output "vpc_id" { value = aws_vpc.this.id }
output "app_subnet_ids" { value = { for k, s in aws_subnet.app : k => s.id } }
output "db_subnet_ids" { value = { for k, s in aws_subnet.db : k => s.id } }
output "cont_zone_id" { value = aws_route53_zone.cont.zone_id }
output "cont_name_servers" { value = aws_route53_zone.cont.name_servers }
output "certificate_arn" { value = aws_acm_certificate_validation.this.certificate_arn }
output "cluster_name" { value = aws_eks_cluster.this.name }
output "cluster_security_group_id" { value = aws_eks_cluster.this.vpc_config[0].cluster_security_group_id }
output "kubeconfig_command" {
  value = "aws eks update-kubeconfig --name ${aws_eks_cluster.this.name} --region ${var.region} --profile ${var.aws_profile}"
}
