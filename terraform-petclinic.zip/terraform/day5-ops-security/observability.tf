# 태스크 1 — Grafana 대시보드(PetClinic)는 Grafana UI 에서 만든다(교안 절차). 데이터 소스는 day3 의 kps.

# 태스크 2 — 경보 규칙 pc-rules (was/web 가용 Pod < 1, for 1m)
#   Slack 수신자는 day3 의 kube-prometheus-stack 에 붙어 있다:
#     cd ../day3-platform-app && TF_VAR_slack_webhook_url=... terraform apply
resource "kubectl_manifest" "rules" {
  for_each  = local.split.rules
  yaml_body = each.value
}

# 태스크 3 — 컨테이너 로그 → CloudWatch Logs (Fluent Bit DaemonSet, Pod Identity)
resource "aws_cloudwatch_log_group" "containers" {
  name              = "/pc/eks/containers"
  retention_in_days = var.log_retention_days
}

resource "aws_iam_role" "fluentbit" {
  name               = "pc-pi-fluentbit"
  assume_role_policy = data.aws_iam_policy_document.pod_identity_assume.json
}

resource "aws_iam_role_policy_attachment" "fluentbit" {
  role       = aws_iam_role.fluentbit.name
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy"
}

resource "aws_eks_pod_identity_association" "fluentbit" {
  cluster_name    = var.cluster_name
  namespace       = "amazon-cloudwatch"
  service_account = "aws-for-fluent-bit"
  role_arn        = aws_iam_role.fluentbit.arn
}

resource "helm_release" "fluentbit" {
  name             = "aws-for-fluent-bit"
  repository       = "https://aws.github.io/eks-charts"
  chart            = "aws-for-fluent-bit"
  version          = var.fluentbit_chart_version
  namespace        = "amazon-cloudwatch"
  create_namespace = true
  values = [yamlencode({
    serviceAccount = { create = true, name = "aws-for-fluent-bit" }
    cloudWatchLogs = {
      enabled         = true
      region          = var.region
      logGroupName    = aws_cloudwatch_log_group.containers.name
      autoCreateGroup = false
    }
    firehose      = { enabled = false }
    kinesis       = { enabled = false }
    elasticsearch = { enabled = false }
    tolerations   = [{ operator = "Exists" }] # 모든 노드(taint 포함)
  })]
  depends_on = [aws_eks_pod_identity_association.fluentbit, aws_iam_role_policy_attachment.fluentbit]
}

# 태스크 3.5 — CloudWatch 트래픽 흐름 대시보드 pc-petclinic-flow (28 위젯)
resource "aws_cloudwatch_dashboard" "flow" {
  dashboard_name = "pc-petclinic-flow"
  dashboard_body = templatefile("${path.module}/templates/pc-petclinic-flow.json.tftpl", {
    alb      = data.aws_lb.alb.arn_suffix
    tg       = data.aws_lb_target_group.ngf.arn_suffix
    nat_a    = data.aws_nat_gateway.this["a"].id
    nat_c    = data.aws_nat_gateway.this["c"].id
    prom_vol = data.aws_ebs_volume.prometheus.id
  })
}
