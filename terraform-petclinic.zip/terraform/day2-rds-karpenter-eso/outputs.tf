output "db_endpoint" { value = aws_db_instance.this.address }
output "db_secret_arn" {
  description = "RDS 관리형 비밀 ARN (값은 출력하지 않는다)"
  value       = aws_db_instance.this.master_user_secret[0].secret_arn
}
output "rds_security_group_id" { value = aws_security_group.rds.id }
output "karpenter_queue" { value = var.cluster_name }
