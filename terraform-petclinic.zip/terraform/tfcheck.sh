#!/bin/bash
# 사용: ./tfcheck.sh day1-network-eks [...]  — init(-backend=false) · fmt · validate 만 수행(plan/apply 안 함)
cd "$(dirname "$0")"
for d in "$@"; do
  echo "===== $d"
  docker run --rm --user $(id -u):$(id -g) -e HOME=/tmp -e TF_PLUGIN_CACHE_DIR=/cache -e TF_IN_AUTOMATION=1 \
    -v "$PWD":/w -v "$PWD/.plugin-cache":/cache -w /w/$d hashicorp/terraform:latest init -backend=false -input=false -no-color >/tmp/tfinit.$$ 2>&1 || { tail -30 /tmp/tfinit.$$; continue; }
  grep -E 'Installed|Using previously' /tmp/tfinit.$$ | sed 's/^- //'
  docker run --rm --user $(id -u):$(id -g) -e HOME=/tmp -v "$PWD":/w -w /w/$d hashicorp/terraform:latest fmt -recursive -no-color
  docker run --rm --user $(id -u):$(id -g) -e HOME=/tmp -e TF_PLUGIN_CACHE_DIR=/cache -v "$PWD":/w -v "$PWD/.plugin-cache":/cache -w /w/$d hashicorp/terraform:latest validate -no-color
done
