output "ecr_repositories" { value = { for k, r in aws_ecr_repository.this : k => r.repository_url } }
output "app_objects" { value = keys(local.app_docs) }
output "grafana_port_forward" {
  value = "kubectl -n monitoring port-forward svc/kps-grafana 3000:80"
}
