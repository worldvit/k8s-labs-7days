# 태스크 1 — VPC (콘솔 마법사 "VPC 등"과 같은 결과)
resource "aws_vpc" "this" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true
  tags                 = { Name = "pc-vpc" }
}

# 메인 라우팅 테이블에도 Project 태그(철거 추적용)
resource "aws_ec2_tag" "main_rtb_project" {
  resource_id = aws_vpc.this.main_route_table_id
  key         = "Project"
  value       = var.project_tag
}

resource "aws_internet_gateway" "this" {
  vpc_id = aws_vpc.this.id
  tags   = { Name = "pc-igw" }
}

resource "aws_subnet" "public" {
  for_each                = var.subnets
  vpc_id                  = aws_vpc.this.id
  cidr_block              = each.value.public
  availability_zone       = each.value.az
  map_public_ip_on_launch = true
  tags = {
    Name                     = "pc-subnet-pub-${each.key}"
    "kubernetes.io/role/elb" = "1"
  }
}

resource "aws_subnet" "app" {
  for_each          = var.subnets
  vpc_id            = aws_vpc.this.id
  cidr_block        = each.value.app
  availability_zone = each.value.az
  tags = {
    Name                              = "pc-subnet-app-${each.key}"
    "kubernetes.io/role/internal-elb" = "1"
    "karpenter.sh/discovery"          = var.cluster_name
  }
}

resource "aws_subnet" "db" {
  for_each          = var.subnets
  vpc_id            = aws_vpc.this.id
  cidr_block        = each.value.db
  availability_zone = each.value.az
  tags              = { Name = "pc-subnet-db-${each.key}" }
}

# 퍼블릭: 0.0.0.0/0 → IGW
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.this.id
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.this.id
  }
  tags = { Name = "pc-rtb-pub" }
}

resource "aws_route_table_association" "public" {
  for_each       = aws_subnet.public
  subnet_id      = each.value.id
  route_table_id = aws_route_table.public.id
}

# NAT 게이트웨이 AZ당 1개
resource "aws_eip" "nat" {
  for_each = var.subnets
  domain   = "vpc"
  tags     = { Name = "pc-eip-${each.key}" }
}

resource "aws_nat_gateway" "this" {
  for_each      = var.subnets
  allocation_id = aws_eip.nat[each.key].id
  subnet_id     = aws_subnet.public[each.key].id
  tags          = { Name = "pc-nat-${each.key}" }
  depends_on    = [aws_internet_gateway.this]
}

# 앱: 같은 AZ의 NAT로만 나간다
resource "aws_route_table" "app" {
  for_each = var.subnets
  vpc_id   = aws_vpc.this.id
  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.this[each.key].id
  }
  tags = { Name = "pc-rtb-app-${each.key}" }
}

resource "aws_route_table_association" "app" {
  for_each       = aws_subnet.app
  subnet_id      = each.value.id
  route_table_id = aws_route_table.app[each.key].id
}

# DB: local 한 줄만(인터넷 경로 없음) — 마법사가 넣는 NAT 경로를 지운 최종 상태
resource "aws_route_table" "db" {
  for_each = var.subnets
  vpc_id   = aws_vpc.this.id
  tags     = { Name = "pc-rtb-db-${each.key}" }
}

resource "aws_route_table_association" "db" {
  for_each       = aws_subnet.db
  subnet_id      = each.value.id
  route_table_id = aws_route_table.db[each.key].id
}
