data "aws_caller_identity" "this" {}

data "aws_eks_cluster" "this" {
  name = var.cluster_name
}

data "aws_lb" "alb" {
  name = "pc-alb"
}

data "aws_lb_target_group" "ngf" {
  tags = {
    "ingress.k8s.aws/stack" = "petclinic/pc-ingress"
    "elbv2.k8s.aws/cluster" = var.cluster_name
  }
}

data "aws_nat_gateway" "this" {
  for_each = toset(["a", "c"])
  state    = "available"
  tags     = { Name = "pc-nat-${each.key}" }
}

# Prometheus PVC 로 동적 생성된 EBS (대시보드 ④ EBS 위젯)
data "aws_ebs_volume" "prometheus" {
  most_recent = true
  filter {
    name   = "tag:kubernetes.io/created-for/pvc/name"
    values = ["prometheus-kps-prometheus-db-prometheus-kps-prometheus-0"]
  }
}

data "aws_iam_policy_document" "pod_identity_assume" {
  statement {
    actions = ["sts:AssumeRole", "sts:TagSession"]
    principals {
      type        = "Service"
      identifiers = ["pods.eks.amazonaws.com"]
    }
  }
}

locals {
  split = { for name, body in {
    rules  = file("${path.module}/manifests/80-rules.yaml")
    backup = file("${path.module}/manifests/90-backup.yaml")
  } : name => { for d in split("\n---\n", body) : "${yamldecode(d).kind}/${yamldecode(d).metadata.name}" => d if trimspace(d) != "" } }
}
