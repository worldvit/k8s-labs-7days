output "waf_arn" { value = aws_wafv2_web_acl.this.arn }
output "log_group" { value = aws_cloudwatch_log_group.containers.name }
output "dashboard_url" {
  value = "https://${var.region}.console.aws.amazon.com/cloudwatch/home?region=${var.region}#dashboards/dashboard/${aws_cloudwatch_dashboard.flow.dashboard_name}"
}
