# 태스크 2 — ECR (불변 태그 · 푸시 시 스캔 · AES256)
resource "aws_ecr_repository" "this" {
  for_each             = toset(["pc-web", "pc-was"])
  name                 = each.key
  image_tag_mutability = "IMMUTABLE"
  force_delete         = false # 이미지가 있으면 삭제를 막는다(철거는 pc-teardown.sh)

  image_scanning_configuration {
    scan_on_push = true
  }

  encryption_configuration {
    encryption_type = "AES256"
  }
}

# 개선 과제 반영: 불변 태그 거부 push 가 남기는 태그 없는 매니페스트 정리
resource "aws_ecr_lifecycle_policy" "untagged" {
  for_each   = aws_ecr_repository.this
  repository = each.value.name
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "expire untagged after 1 day"
      selection    = { tagStatus = "untagged", countType = "sinceImagePushed", countUnit = "days", countNumber = 1 }
      action       = { type = "expire" }
    }]
  })
}

# 이미지 빌드·push 는 Terraform 밖에서 한다(실습 2 태스크 4, 실습 3 태스크 1~2):
#   ../scripts/build-push.sh   — Maven 컨테이너 빌드 → docker build pc-web·pc-was → ECR push
