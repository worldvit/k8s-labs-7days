# 태스크 5 — 카나리 배포 (web-canary + exporter 사이드카, HTTPRoute 가중치로 분배)
#   terraform apply -var enable_canary=true -var canary_weight=10
#   terraform apply -var enable_canary=true -var canary_weight=50
#   terraform apply -var enable_canary=false            # 원복(가중치 100:0, web-canary 삭제)
resource "kubectl_manifest" "canary" {
  for_each = var.enable_canary ? {
    for d in split("\n---\n", templatefile("${path.module}/manifests/71-canary.yaml.tftpl", { registry = local.registry, web_tag = var.web_tag })) :
    "${yamldecode(d).kind}/${yamldecode(d).metadata.name}" => d if trimspace(d) != ""
  } : {}
  yaml_body = each.value
}
