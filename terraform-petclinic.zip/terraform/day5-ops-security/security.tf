# 태스크 4 — WAF 와 EKS 엔드포인트 제한
resource "aws_wafv2_web_acl" "this" {
  name  = "pc-waf"
  scope = "REGIONAL"

  default_action {
    allow {}
  }

  rule {
    name     = "AWS-AWSManagedRulesCommonRuleSet"
    priority = 0
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        vendor_name = "AWS"
        name        = "AWSManagedRulesCommonRuleSet"
      }
    }
    visibility_config {
      sampled_requests_enabled   = true
      cloudwatch_metrics_enabled = true
      metric_name                = "AWS-AWSManagedRulesCommonRuleSet"
    }
  }

  rule {
    name     = "AWS-AWSManagedRulesSQLiRuleSet"
    priority = 1
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        vendor_name = "AWS"
        name        = "AWSManagedRulesSQLiRuleSet"
      }
    }
    visibility_config {
      sampled_requests_enabled   = true
      cloudwatch_metrics_enabled = true
      metric_name                = "AWS-AWSManagedRulesSQLiRuleSet"
    }
  }

  rule {
    name     = "RateLimitPerIP"
    priority = 2
    action {
      block {}
    }
    statement {
      rate_based_statement {
        limit                 = var.waf_rate_limit
        evaluation_window_sec = 300
        aggregate_key_type    = "IP"
      }
    }
    visibility_config {
      sampled_requests_enabled   = true
      cloudwatch_metrics_enabled = true
      metric_name                = "RateLimitPerIP"
    }
  }

  visibility_config {
    sampled_requests_enabled   = true
    cloudwatch_metrics_enabled = true
    metric_name                = "pc-waf"
  }
}

# WAF 연결은 ALB 를 관리하는 Ingress 주석으로만 한다(LBC 가 연결·해제를 맡음).
# day4 의 Ingress 에 주석 하나만 서버 사이드 적용으로 붙인다.
resource "kubernetes_annotations" "ingress_waf" {
  api_version = "networking.k8s.io/v1"
  kind        = "Ingress"
  metadata {
    name      = "pc-ingress"
    namespace = "petclinic"
  }
  annotations = {
    "alb.ingress.kubernetes.io/wafv2-acl-arn" = aws_wafv2_web_acl.this.arn
  }
  force = true
}

# EKS API 퍼블릭 엔드포인트 제한은 클러스터를 소유한 day1 에서 변수로 바꾼다:
#   cd ../day1-network-eks && terraform apply -var 'public_access_cidrs=["<강사 IP>/32"]'
