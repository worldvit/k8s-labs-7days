#!/usr/bin/env bash
# 실습 2 태스크 4 · 실습 3 태스크 1~2 — PetClinic WAR 빌드 → pc-web·pc-was 이미지 → ECR push
# 사용: scripts/build-push.sh <web_tag> <was_tag>   (예: 1.0.0 1.0.1)
# 전제: ~/pc/spring-framework-petclinic (pom.xml 드라이버 좌표·placeholder 수정 반영), day3 apply 로 ECR 생성 완료
#       ECR 은 IMMUTABLE — 이미 있는 태그로는 push 가 거부된다. 새 빌드는 새 태그로.
set -euo pipefail
WEB_TAG=${1:?web tag}; WAS_TAG=${2:?was tag}
PROFILE=${AWS_PROFILE:-p6762}; REGION=ap-northeast-2
SRC=${SRC:-$HOME/pc/spring-framework-petclinic}
ACCOUNT=$(aws sts get-caller-identity --profile "$PROFILE" --query Account --output text)
[ "$ACCOUNT" = "676206941602" ] || { echo "계정 불일치: $ACCOUNT"; exit 1; }
ECR=$ACCOUNT.dkr.ecr.$REGION.amazonaws.com

# 1) WAR 빌드 — 노트북에 Java 없이 Maven 컨테이너로 (-PMySQL)
docker run --rm -v "$SRC":/src -v "$HOME/.m2":/root/.m2 -w /src maven:3.9-eclipse-temurin-17 \
  mvn -q -B -PMySQL -DskipTests package

# 2) 이미지 빌드 (빌드 컨텍스트 = 소스 루트, Dockerfile 은 pc-docker/)
[ -d "$SRC/pc-docker" ] || cp -r "$(dirname "$0")/../images/pc-docker" "$SRC/"
docker build -t pc-web:"$WEB_TAG" -f "$SRC/pc-docker/web/Dockerfile" "$SRC"
docker build -t pc-was:"$WAS_TAG" -f "$SRC/pc-docker/was/Dockerfile" "$SRC"

# 3) ECR 로그인·push
aws ecr get-login-password --profile "$PROFILE" --region $REGION | docker login --username AWS --password-stdin "$ECR"
for pair in "pc-web:$WEB_TAG" "pc-was:$WAS_TAG"; do
  docker tag "$pair" "$ECR/$pair"
  docker push "$ECR/$pair"
done

# 4) 스캔 결과(OCI 인덱스면 하위 이미지 매니페스트에 붙는다)
aws ecr describe-image-scan-findings --profile "$PROFILE" --region $REGION --repository-name pc-was --image-id imageTag="$WAS_TAG" \
  --query 'imageScanFindings.findingSeverityCounts' 2>/dev/null || echo "스캔 진행 중이거나 인덱스 하위 매니페스트로 조회 필요"
echo "완료. day3 에서: terraform apply -var web_tag=$WEB_TAG -var was_tag=$WAS_TAG"
