# 태스크 3 — 플랫폼 3종: KEDA · NGINX Gateway Fabric · kube-prometheus-stack

resource "helm_release" "keda" {
  name             = "keda"
  repository       = "https://kedacore.github.io/charts"
  chart            = "keda"
  version          = var.keda_chart_version
  namespace        = "keda"
  create_namespace = true
  values = [yamlencode({
    nodeSelector = local.critical_selector
    tolerations  = local.critical_toleration
  })]
}

# Gateway API CRD (standard 채널) — NGF 보다 먼저
data "http" "gateway_api_crds" {
  url = "https://github.com/kubernetes-sigs/gateway-api/releases/download/${var.gateway_api_version}/standard-install.yaml"
}

data "kubectl_file_documents" "gateway_api_crds" {
  content = data.http.gateway_api_crds.response_body
}

resource "kubectl_manifest" "gateway_api_crds" {
  for_each          = data.kubectl_file_documents.gateway_api_crds.manifests
  yaml_body         = each.value
  server_side_apply = true
}

resource "helm_release" "ngf" {
  name             = "ngf"
  repository       = "oci://ghcr.io/nginx/charts"
  chart            = "nginx-gateway-fabric"
  version          = var.ngf_chart_version
  namespace        = "nginx-gateway"
  create_namespace = true
  values = [yamlencode({
    nginxGateway = { nodeSelector = local.critical_selector, tolerations = local.critical_toleration }
    nginx        = { replicas = 2, service = { type = "ClusterIP" } } # 입구는 ALB 가 맡는다
  })]
  depends_on = [kubectl_manifest.gateway_api_crds]
}

# kube-prometheus-stack — platform 노드, Prometheus PVC 10Gi(pc-gp3)
locals {
  # 실습 5 태스크 2: Webhook 이 있으면 Alertmanager → Slack (발생·해제, Watchdog 무시)
  alertmanager_values = var.slack_webhook_url == "" ? {} : {
    alertmanager = {
      config = {
        global = { resolve_timeout = "5m" }
        route = {
          receiver        = "slack"
          group_by        = ["alertname", "namespace"]
          group_wait      = "30s"
          group_interval  = "5m"
          repeat_interval = "3h"
          routes = [
            { receiver = "null", matchers = ["alertname = \"Watchdog\""] },
            { receiver = "null", matchers = ["alertname = \"InfoInhibitor\""] },
          ]
        }
        receivers = [
          { name = "null" },
          { name = "slack", slack_configs = [{
            api_url       = var.slack_webhook_url
            channel       = var.slack_channel
            send_resolved = true
            title         = "[{{ .Status | toUpper }}] {{ .CommonLabels.alertname }}"
            text          = "{{ range .Alerts }}{{ .Annotations.summary }}{{ \"\\n\" }}{{ end }}"
          }] },
        ]
      }
    }
  }
}

resource "helm_release" "kps" {
  name             = "kps"
  repository       = "https://prometheus-community.github.io/helm-charts"
  chart            = "kube-prometheus-stack"
  version          = var.kps_chart_version
  namespace        = "monitoring"
  create_namespace = true
  timeout          = 900
  values = [
    file("${path.module}/values/kps-values.yaml"),
    yamlencode(local.alertmanager_values),
  ]
}
